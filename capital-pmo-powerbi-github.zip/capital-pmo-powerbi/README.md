# Capital PMO Portfolio Dashboard | Power BI + Python + DAX

A reproducible **fictional manufacturing capital portfolio** dataset and a step-by-step Power BI dashboard blueprint. This project models how a capital project management office (PMO) might review capital expenditure, budget groups, project approval stage gates, document compliance, and year-over-year performance.

> **Portfolio disclosure:** All facilities, projects, spending, budgets, stage gate records and statuses are **synthetically generated** and do not represent Hershey or any other company's actual information. This project is independent and unaffiliated with The Hershey Company.

## What's included

- `scripts/generate_data.py` — deterministic Python generator, no third-party dependencies
- `data/projects.csv` — 80 fictional capital projects and budgets
- `data/monthly_spend.csv` — monthly expenditure records (960 rows)
- `data/stage_gates.csv` — stage gate decisions and document completeness
- `powerbi/measures.dax` — Power BI measures for spending, variance, risk, approvals, compliance and YoY
- `docs/BUILD_GUIDE.md` — detailed dashboard build and GitHub publishing guide
- `tests/test_data.py` — data integrity tests

## Quick start

1. Install [Power BI Desktop](https://www.microsoft.com/en-us/power-platform/products/power-bi/desktop) on Windows.
2. Open Power BI Desktop. Choose **Get data > Text/CSV**, then load each CSV from `data/`.
3. In **Power Query**, rename the queries to `Projects`, `MonthlySpend`, and `StageGates` respectively. Set `PlanYear` to Whole Number, `ApprovedBudget` and `ActualSpend` to Fixed Decimal Number, and `SpendDate` / `ReviewDate` to Date. Select **Close & Apply**.
4. In Model view, establish **one-to-many** relationships from `Projects[ProjectID]` to `MonthlySpend[ProjectID]` and `StageGates[ProjectID]` with **single** filter direction.
5. Copy each measure from `powerbi/measures.dax` and add it through **Modeling > New measure**. Do not paste the entire file into one measure; each formula is separate.
6. Follow `docs/BUILD_GUIDE.md` to create dashboard visuals, slicers, and a drill-through view.
7. Save the finished report in this repository, ideally using **File > Save As > Power BI project (.pbip)** for Git-friendly version history. You can also save a `.pbix` file. Save screenshots to `docs/screenshots/`.
8. Add dashboard screenshots to this README once they exist, then push the project to GitHub.

**Regenerate data:** `python scripts/generate_data.py`  
**Run tests:** `python -m unittest discover -s tests -v`

## Suggested dashboard pages

| Page | Questions answered | Suggested visuals |
|---|---|---|
| Executive Overview | How much is budgeted/spent? Which groups are at risk? | KPI cards, bar charts by facility, project status donut |
| Capital Governance | Which projects are approved? Are stage-gate documents complete? | Approval funnel, stage-gate compliance KPI, details table |
| Year-over-Year | How do budgets and costs change by plan year? | Budget/spend clustered columns, annual trends |

## Example portfolio talking point

"I generated a reproducible synthetic dataset, built a relational Power BI model and DAX KPIs to analyze capital budgets, monthly spending, approval status, and stage-gate documentation compliance."

Use this description **only after you have actually built and validated the Power BI report**. The repository initially contains **data, code, and build instructions, not a completed `.pbix` dashboard**.

## Data interpretation

`ApprovedBudget` means the **planned portfolio budget figure** in the sample dataset, *not* necessarily a formally authorized amount. `ApprovalStatus` indicates whether the project has passed the fictional gate process. All spend records are assigned within each project's `PlanYear`. The figures are intentionally constructed for skills demonstration and should not be used for operational decisions.

## License

MIT — see `LICENSE`.
